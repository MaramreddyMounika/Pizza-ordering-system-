﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ThePizzazHouse.Models
{
    public class PizzaDetails
    {
        [Key]
        public int PizzaId { get; set; }


        public string PizzaName { get; set; }


        public decimal PizzaCost { get; set; }


        public string PizzaDescription { get; set; }

        public string PizzaImage { get; set; }

        [ForeignKey("PizzaStoreDetails")]
        public int StoreId { get; set; }

        public virtual PizzaStoreDetails? PizzaStoreDetails { get; set; }

    }
}
