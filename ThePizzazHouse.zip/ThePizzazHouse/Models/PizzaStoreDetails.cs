﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ThePizzazHouse.Models
{
    public class PizzaStoreDetails
    {
        public PizzaStoreDetails()
        {
            PizzaData = new HashSet<PizzaDetails>();
        }
        [Key]
        public int StoreId { get; set; }
        public string StoreImage { get; set; }
        public string StoreName { get; set; }
        public string StoreAddress { get; set; }
        public string StoreCity { get; set; }
        public string StoreState { get; set; }
        public string StoreZipCode { get; set; }
        public string PhoneNumber { get; set; }
        public virtual ICollection<PizzaDetails> PizzaData { get; set; }
    }
}
