﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ThePizzazHouse.Models
{
    public class Carts
    {
        [Key]
        public int CartId { get; set; }
        [ForeignKey("UserLoginDetails")]
        public string? UserId { get; set; }
        [ForeignKey("PizzaDetails")]
        public int PizzaId { get; set; }
        public string? PizzaName { get; set; }
        public virtual PizzaDetails? PizzaDetails { get; set; }
        public virtual UserLoginDetails? UserLoginDetails { get; set; }

    }
}
