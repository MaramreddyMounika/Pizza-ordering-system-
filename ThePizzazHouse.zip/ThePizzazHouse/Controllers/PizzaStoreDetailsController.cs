﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ThePizzazHouse.Data;
using ThePizzazHouse.Models;

namespace ThePizzazHouse.Controllers
{
    public class PizzaStoreDetailsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public PizzaStoreDetailsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: PizzaStoreDetails
        public async Task<IActionResult> Index()
        {
              return _context.PizzaStoreData != null ? 
                          View(await _context.PizzaStoreData.ToListAsync()) :
                          Problem("Entity set 'ApplicationDbContext.PizzaStoreData'  is null.");
        }

        // GET: PizzaStoreDetails/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.PizzaStoreData == null)
            {
                return NotFound();
            }

            var pizzaStoreDetails = await _context.PizzaStoreData
                .FirstOrDefaultAsync(m => m.StoreId == id);
            if (pizzaStoreDetails == null)
            {
                return NotFound();
            }

            return View(pizzaStoreDetails);
        }

        // GET: PizzaStoreDetails/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: PizzaStoreDetails/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("StoreId,StoreImage,StoreName,StoreAddress,StoreCity,StoreState,StoreZipCode,PhoneNumber")] PizzaStoreDetails pizzaStoreDetails)
        {
            if (ModelState.IsValid)
            {
                _context.Add(pizzaStoreDetails);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(pizzaStoreDetails);
        }

        // GET: PizzaStoreDetails/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.PizzaStoreData == null)
            {
                return NotFound();
            }

            var pizzaStoreDetails = await _context.PizzaStoreData.FindAsync(id);
            if (pizzaStoreDetails == null)
            {
                return NotFound();
            }
            return View(pizzaStoreDetails);
        }

        // POST: PizzaStoreDetails/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("StoreId,StoreImage,StoreName,StoreAddress,StoreCity,StoreState,StoreZipCode,PhoneNumber")] PizzaStoreDetails pizzaStoreDetails)
        {
            if (id != pizzaStoreDetails.StoreId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(pizzaStoreDetails);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PizzaStoreDetailsExists(pizzaStoreDetails.StoreId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(pizzaStoreDetails);
        }

        // GET: PizzaStoreDetails/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.PizzaStoreData == null)
            {
                return NotFound();
            }

            var pizzaStoreDetails = await _context.PizzaStoreData
                .FirstOrDefaultAsync(m => m.StoreId == id);
            if (pizzaStoreDetails == null)
            {
                return NotFound();
            }

            return View(pizzaStoreDetails);
        }

        // POST: PizzaStoreDetails/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.PizzaStoreData == null)
            {
                return Problem("Entity set 'ApplicationDbContext.PizzaStoreData'  is null.");
            }
            var pizzaStoreDetails = await _context.PizzaStoreData.FindAsync(id);
            if (pizzaStoreDetails != null)
            {
                _context.PizzaStoreData.Remove(pizzaStoreDetails);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PizzaStoreDetailsExists(int id)
        {
          return (_context.PizzaStoreData?.Any(e => e.StoreId == id)).GetValueOrDefault();
        }
    }
}
