﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ThePizzazHouse.Data;
using ThePizzazHouse.Models;

namespace ThePizzazHouse.Controllers
{
    public class PizzasDetails : Controller
    {
        private readonly ApplicationDbContext _context;
        UserManager<IdentityUser> _userManager;
        public PizzasDetails(ApplicationDbContext context, UserManager<IdentityUser> userManager)
        {
            _context = context;
            this._userManager = userManager;
        }

        //Get:Pizza
        public async Task<IActionResult> index()
        {
            var pizzas = await _context.PizzaData.ToListAsync();
            return View(pizzas);
        }

        public IActionResult Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pizadata = _context.PizzaData.Where(i=>i.StoreId==id).ToList();
            if (pizadata == null)
            {
                return NotFound();
            }

            return View(pizadata);
        }
        public IActionResult AddToCart(int id)
        {
            TempData["camsg"] = "Added To Cart";
            string uid = _userManager.Users.Where(i => i.UserName == HttpContext.Session.GetString("user")).FirstOrDefault().Id;
            var pizzaname = _context.PizzaData.Where(i => i.PizzaId == id).First().PizzaName;
            _context.Cart.Add(new Carts() { PizzaId = id, UserId = uid, PizzaName = pizzaname });
            _context.SaveChanges();
            return RedirectToAction("Index", "Home");
        }
    }
}
