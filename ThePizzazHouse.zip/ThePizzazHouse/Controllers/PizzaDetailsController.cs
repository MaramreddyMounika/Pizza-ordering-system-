﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ThePizzazHouse.Data;
using ThePizzazHouse.Models;

namespace ThePizzazHouse.Controllers
{
    public class PizzaDetailsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public PizzaDetailsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: PizzaDetails
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.PizzaData.Include(p => p.PizzaStoreDetails);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: PizzaDetails/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.PizzaData == null)
            {
                return NotFound();
            }

            var pizzaDetails = await _context.PizzaData
                .Include(p => p.PizzaStoreDetails)
                .FirstOrDefaultAsync(m => m.PizzaId == id);
            if (pizzaDetails == null)
            {
                return NotFound();
            }

            return View(pizzaDetails);
        }

        // GET: PizzaDetails/Create
        public IActionResult Create()
        {
            ViewData["StoreId"] = new SelectList(_context.PizzaStoreData, "StoreId", "StoreId");
            return View();
        }

        // POST: PizzaDetails/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PizzaId,PizzaName,PizzaCost,PizzaDescription,PizzaImage,StoreId")] PizzaDetails pizzaDetails)
        {
            if (ModelState.IsValid)
            {
                _context.Add(pizzaDetails);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["StoreId"] = new SelectList(_context.PizzaStoreData, "StoreId", "StoreId", pizzaDetails.StoreId);
            return View(pizzaDetails);
        }

        // GET: PizzaDetails/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.PizzaData == null)
            {
                return NotFound();
            }

            var pizzaDetails = await _context.PizzaData.FindAsync(id);
            if (pizzaDetails == null)
            {
                return NotFound();
            }
            ViewData["StoreId"] = new SelectList(_context.PizzaStoreData, "StoreId", "StoreId", pizzaDetails.StoreId);
            return View(pizzaDetails);
        }

        // POST: PizzaDetails/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PizzaId,PizzaName,PizzaCost,PizzaDescription,PizzaImage,StoreId")] PizzaDetails pizzaDetails)
        {
            if (id != pizzaDetails.PizzaId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(pizzaDetails);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PizzaDetailsExists(pizzaDetails.PizzaId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["StoreId"] = new SelectList(_context.PizzaStoreData, "StoreId", "StoreId", pizzaDetails.StoreId);
            return View(pizzaDetails);
        }

        // GET: PizzaDetails/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.PizzaData == null)
            {
                return NotFound();
            }

            var pizzaDetails = await _context.PizzaData
                .Include(p => p.PizzaStoreDetails)
                .FirstOrDefaultAsync(m => m.PizzaId == id);
            if (pizzaDetails == null)
            {
                return NotFound();
            }

            return View(pizzaDetails);
        }

        // POST: PizzaDetails/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.PizzaData == null)
            {
                return Problem("Entity set 'ApplicationDbContext.PizzaData'  is null.");
            }
            var pizzaDetails = await _context.PizzaData.FindAsync(id);
            if (pizzaDetails != null)
            {
                _context.PizzaData.Remove(pizzaDetails);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PizzaDetailsExists(int id)
        {
          return (_context.PizzaData?.Any(e => e.PizzaId == id)).GetValueOrDefault();
        }
    }
}
