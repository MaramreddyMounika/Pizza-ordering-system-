﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Data;

namespace ThePizzazHouse.Controllers
{

    [Authorize(Roles ="Admin")]
    public class UserController : Controller
    {
        UserManager<IdentityUser> userManager;
        public UserController(UserManager<IdentityUser> _userManager)
        {
            userManager = _userManager;

        }
        public IActionResult Index()
        {
            var data = userManager.Users.ToList();
            if (data == null)
            {
                return NotFound();
            }
            return View(data);
        }
    }
}
