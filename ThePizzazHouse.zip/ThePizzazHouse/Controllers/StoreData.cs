﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ThePizzazHouse.Data;

namespace ThePizzazHouse.Controllers
{
    public class StoreData : Controller
    {

        private readonly ApplicationDbContext _context;

        public StoreData(ApplicationDbContext context)
        {
            _context = context;
        }
        //Get: PizzaStore
        public async Task<IActionResult> index()
        {
            var pizzaStores = await _context.PizzaStoreData.ToListAsync();
            return View(pizzaStores);
        }
        public IActionResult Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pizzaStore = _context.PizzaStoreData.FirstOrDefault(p => p.StoreId == id);
            if (pizzaStore == null)
            {
                return NotFound();
            }

            return View(pizzaStore);
        }
    }
}
