﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using ThePizzazHouse.Models;

namespace ThePizzazHouse.Data
{
    public class ApplicationDbContext:IdentityDbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=(localdb)\MSSQLLocalDB;Database=PizzazHouseDb;Trusted_Connection=True;TrustServerCertificate=true;");
        }
        public DbSet<ThePizzazHouse.Models.UserLoginDetails> UserData { get; set; }
        public DbSet<ThePizzazHouse.Models.PizzaStoreDetails> PizzaStoreData { get; set; }
        public DbSet<ThePizzazHouse.Models.PizzaDetails> PizzaData { get; set; }
        public DbSet<Carts> Cart { get; set; }

    }
}
