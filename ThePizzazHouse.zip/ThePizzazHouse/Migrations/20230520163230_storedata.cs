﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ThePizzazHouse.Migrations
{
    public partial class storedata : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "PizzaStoreData",
                columns: table => new
                {
                    StoreId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StoreImage = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StoreName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StoreAddress = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StoreCity = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StoreState = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StoreZipCode = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PizzaStoreData", x => x.StoreId);
                });

            migrationBuilder.CreateTable(
                name: "PizzaData",
                columns: table => new
                {
                    PizzaId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PizzaName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PizzaCost = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    PizzaDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PizzaImage = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StoreId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PizzaData", x => x.PizzaId);
                    table.ForeignKey(
                        name: "FK_PizzaData_PizzaStoreData_StoreId",
                        column: x => x.StoreId,
                        principalTable: "PizzaStoreData",
                        principalColumn: "StoreId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_PizzaData_StoreId",
                table: "PizzaData",
                column: "StoreId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "PizzaData");

            migrationBuilder.DropTable(
                name: "PizzaStoreData");
        }
    }
}
